﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Resources;
using System.Reflection;
using System.Text;
using System.Windows.Forms;
using Microsoft.WindowsAPICodePack.Taskbar;

namespace RecyclePin
{
	public partial class RecyclePinForm : Form
	{
		#region Fields
		private ShellNotifications Notifications = new ShellNotifications();
		private ThumbnailToolbarButton tbtn_empty;
		private ThumbnailToolbarSeparator tbtn_seperator;
		private ThumbnailToolbarButton tbtn_close;
		private TabbedThumbnail thumb;
		private TaskbarManager taskbar = TaskbarManager.Instance;
		#endregion Fields

		#region Methods
		public RecyclePinForm()
		{
			this.InitializeComponent();
			// note: thumbnail previes before thumbnail buttons!
			thumb = new TabbedThumbnail(this.Handle, this.Handle);
			thumb.DisplayFrameAroundBitmap = false;
			taskbar.TabbedThumbnail.AddThumbnailPreview(thumb);
			thumb.SetImage(Properties.Resources.laptop);
			thumb.SetWindowIcon(this.Icon);
			thumb.DisplayFrameAroundBitmap = false;
			thumb.TabbedThumbnailClosed += new EventHandler<TabbedThumbnailEventArgs>(thumb_TabbedThumbnailClosed);

			tbtn_empty = new ThumbnailToolbarButton(Properties.Resources.Empty, "Empty Recycle Bin");
			tbtn_empty.Click += new EventHandler<ThumbnailButtonClickedEventArgs>(tbtn_empty_Click);
			tbtn_seperator = new ThumbnailToolbarSeparator();
			tbtn_close = new ThumbnailToolbarButton(Properties.Resources.Close, "Close");
			tbtn_close.Click += new EventHandler<ThumbnailButtonClickedEventArgs>(tbtn_close_Click);
			taskbar.ThumbnailToolbars.AddButtons(this.Handle, tbtn_empty, tbtn_seperator, tbtn_close);
			
			this.UpdateIcon();
			this.Notifications.RegisterChangeNotify(this.Handle, ShellNotifications.CSIDL.CSIDL_DESKTOP, true);
		}

		private void NewOperation(NotifyInfos infos)
		{
			if ((infos.Notification == ShellNotifications.SHCNE.SHCNE_DELETE) || infos.Item1.Contains("$Recycle.Bin"))
			{
				this.UpdateIcon();
			}
		}

		private void UpdateIcon()
		{
			if (RecycleBin.GetItems() > 0)
			{
				tbtn_empty.Enabled = true;
				thumb.SetWindowIcon(base.Icon = Properties.Resources.bin_full);
			}
			else
			{
				tbtn_empty.Enabled = false;
				thumb.SetWindowIcon(base.Icon = Properties.Resources.bin_empty);
			}
		}
		#endregion Methods

		#region Overrides
		protected override void WndProc(ref Message m)
		{
			if ((m.Msg == 0x401) && this.Notifications.NotificationReceipt(m.WParam, m.LParam))
			{
				this.NewOperation((NotifyInfos)this.Notifications.NotificationsReceived[this.Notifications.NotificationsReceived.Count - 1]);
			}
			base.WndProc(ref m);
		}

		protected override CreateParams CreateParams
		{
			get
			{
				CreateParams cp = base.CreateParams;
				cp.ExStyle |= 0x80;  // turn on WS_EX_TOOLWINDOW style bit;
				return cp;
			}
		}
		#endregion Overrides

		#region Events
		private void RecyclePinForm_Closing(object sender, CancelEventArgs e)
		{
			this.Notifications.UnregisterChangeNotify();
		}

		private void tbtn_empty_Click(object sender, ThumbnailButtonClickedEventArgs e)
		{
			RecycleBin.Empty();
			this.UpdateIcon();
		}

		private void tbtn_close_Click(object sender, ThumbnailButtonClickedEventArgs e)
		{
			Application.Exit();
		}

		private void thumb_TabbedThumbnailClosed(object sender, TabbedThumbnailEventArgs e)
		{
			Application.Exit();
		}
		#endregion Events
	}
}