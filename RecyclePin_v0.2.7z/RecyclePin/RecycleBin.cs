﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;

namespace RecyclePin
{
	public class RecycleBin
	{
		// Methods
		public static int GetItems()
		{
			int num = 0;
			try
			{
				SHQUERYRBINFO structure = new SHQUERYRBINFO();
				structure.cbSize = (uint)Marshal.SizeOf(structure);
				SHQueryRecycleBin(IntPtr.Zero, ref structure);
				num = (int)structure.i64NumItems;
			}
			catch { }
			return num;
		}
		public static uint Empty()
		{
			return SHEmptyRecycleBin(IntPtr.Zero, null, 0);
		}

		#region DllImports
		[DllImport("shell32.dll", CharSet = CharSet.Unicode)]
		private static extern int SHQueryRecycleBin(IntPtr pszRootPath, ref SHQUERYRBINFO pSHQueryRBInfo);

		[DllImport("Shell32.dll", CharSet = CharSet.Unicode)]
		private static extern uint SHEmptyRecycleBin(IntPtr hwnd, string pszRootPath, RecycleFlags dwFlags);
		#endregion DllImports

		// Nested Types
		[StructLayout(LayoutKind.Sequential, Pack = 1)]
		public struct SHQUERYRBINFO
		{
			public uint cbSize;
			public ulong i64Size;
			public ulong i64NumItems;
		}

		public enum RecycleFlags : uint
		{
			SHERB_NOCONFIRMATION = 0x00000001,
			SHERB_NOPROGRESSUI = 0x00000002,
			SHERB_NOSOUND = 0x00000004
		}
	}
}