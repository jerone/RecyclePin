﻿using System;
using System.Windows.Forms;

namespace RecyclePin
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
		[STAThread]
		static void Main()
		{
			bool isOwned = false;
			System.Threading.Mutex appStartMutex = new System.Threading.Mutex(
			   true,
			   Application.ProductName,
			   out isOwned
			);

			if (!isOwned)
			{
				MessageBox.Show(String.Format("{0} is already running!", Application.ProductName), "Already active", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			}
			else
			{
				Application.EnableVisualStyles();
				Application.SetCompatibleTextRenderingDefault(false);
				Application.Run(new RecyclePinForm());
			}
		}
    }
}
