﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Resources;
using System.Reflection;
using System.Text;
using System.Windows.Forms;

namespace RecyclePin
{
    public partial class Form1 : Form
    {
        // Fields
        private Icon BinEmpty;
        private Icon BinFull;
        private ShellNotifications Notifications = new ShellNotifications();
        private ResourceManager Resources = new ResourceManager("RecyclePin.Properties.Resources", Assembly.GetExecutingAssembly());

        // Methods
        public Form1()
        {
            this.InitializeComponent();
            this.BinEmpty = (Icon)this.Resources.GetObject("bin_empty");
            this.BinFull = (Icon)this.Resources.GetObject("bin_full");
            this.UpdateIcon();
            this.Notifications.RegisterChangeNotify(base.Handle, ShellNotifications.CSIDL.CSIDL_DESKTOP, true);
        }

        private void Form1_Closing(object sender, CancelEventArgs e)
        {
            this.Notifications.UnregisterChangeNotify();
        }

        private void NewOperation(NotifyInfos infos)
        {
            if ((infos.Notification == ShellNotifications.SHCNE.SHCNE_DELETE) || infos.Item1.Contains("$Recycle.Bin"))
            {
                this.UpdateIcon();
            }
        }

        private void UpdateIcon()
        {
            if (RecycleBin.GetItems() > 0)
            {
                base.Icon = this.BinFull;
            }
            else
            {
                base.Icon = this.BinEmpty;
            }
        }

        protected override void WndProc(ref Message m)
        {
            if ((m.Msg == 0x401) && this.Notifications.NotificationReceipt(m.WParam, m.LParam))
            {
                this.NewOperation((NotifyInfos)this.Notifications.NotificationsReceived[this.Notifications.NotificationsReceived.Count - 1]);
            }
            base.WndProc(ref m);
        }
    }


}
