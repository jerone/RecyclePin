﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;

namespace RecyclePin
{
    public class RecycleBin
    {
        // Methods
        public static int GetItems()
        {
            int num = 0;
            try
            {
                SHQUERYRBINFO structure = new SHQUERYRBINFO();
                structure.cbSize = (uint)Marshal.SizeOf(structure);
                SHQueryRecycleBin(IntPtr.Zero, ref structure);
                num = (int)structure.i64NumItems;
            }
            catch
            {
            }
            return num;
        }

        [DllImport("shell32.dll")]
        public static extern int SHQueryRecycleBin(IntPtr pszRootPath, ref SHQUERYRBINFO pSHQueryRBInfo);

        // Nested Types
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct SHQUERYRBINFO
        {
            public uint cbSize;
            public ulong i64Size;
            public ulong i64NumItems;
        }
    }


}
